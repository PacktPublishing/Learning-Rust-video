
fn main() {
    let mut values = vec![1, 2, 3, 4];

    // let d = &mut values;    

    let a = &values;
    let b = &values;
    let c = &values;

    // let d = &mut values;
}
